import ResizableLayout from "./components/ResizableLayout";

function App() {
  return (
    <div>
      <ResizableLayout />
    </div>
  );
}

export default App;
